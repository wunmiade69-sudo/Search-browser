(() => {
  'use strict';
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const ENGINE_KEY = 'shorts-browser-search-engine-v1';
  const THEME_KEY = 'shorts-browser-theme-v1';
  const RECENTS_KEY = 'shorts-browser-recent-sites-v1';
  let toastTimer = null;

  function toast(message) {
    const el = $('#toast');
    if (!el) return;
    el.textContent = message;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('show'), 2600);
  }

  function validEngine(value) {
    return ['google','bing','brave','duckduckgo','yahoo','ecosia','startpage','ask','yandex','aol','qwant','mojeek','wikipedia','youtube'].includes(value);
  }

  function loadPreferences() {
    let engine = 'google';
    let theme = 'dark';
    try {
      const storedEngine = localStorage.getItem(ENGINE_KEY);
      if (validEngine(storedEngine)) engine = storedEngine;
      theme = localStorage.getItem(THEME_KEY) === 'light' ? 'light' : 'dark';
    } catch (_) {}
    $('#searchEngine').value = engine;
    $('#settingsSearchEngine').value = engine;
    document.documentElement.dataset.theme = theme;
    document.body.classList.toggle('light', theme === 'light');
    $('#themeButton').textContent = theme === 'dark' ? '☼' : '☾';
  }

  function saveEngine(value) {
    const engine = validEngine(value) ? value : 'google';
    $('#searchEngine').value = engine;
    $('#settingsSearchEngine').value = engine;
    try { localStorage.setItem(ENGINE_KEY, engine); } catch (_) {}
    location.href = `shorts://setsearch?engine=${encodeURIComponent(engine)}`;
  }

  function setTheme() {
    const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.theme = next;
    document.body.classList.toggle('light', next === 'light');
    $('#themeButton').textContent = next === 'dark' ? '☼' : '☾';
    try { localStorage.setItem(THEME_KEY, next); } catch (_) {}
  }

  function showPanel(panelId) {
    $$('.panel').forEach(panel => panel.classList.toggle('active', panel.id === panelId));
    $$('.bottom-item[data-panel]').forEach(item => {
      const active = item.dataset.panel === panelId;
      item.classList.toggle('active', active);
      if (active) item.setAttribute('aria-current', 'page'); else item.removeAttribute('aria-current');
    });
    window.scrollTo({top: 0, behavior: 'smooth'});
  }

  function searchOrOpen(raw) {
    const value = String(raw || '').trim();
    if (!value) { toast('Type a search or website first.'); return; }
    const engine = $('#searchEngine').value || 'google';
    if (/^https?:\/\//i.test(value)) {
      location.href = `shorts://open?url=${encodeURIComponent(value)}`;
      return;
    }
    const looksLikeDomain = !/\s/.test(value) && /^(localhost|[\w-]+(?:\.[\w-]+)+)(?::\d+)?(?:\/[^\s]*)?$/i.test(value);
    if (looksLikeDomain) {
      location.href = `shorts://open?url=${encodeURIComponent('https://' + value)}`;
      return;
    }
    location.href = `shorts://search?q=${encodeURIComponent(value)}&engine=${encodeURIComponent(engine)}`;
  }

  function getRecents() {
    try {
      const parsed = JSON.parse(localStorage.getItem(RECENTS_KEY) || '[]');
      return Array.isArray(parsed) ? parsed.filter(item => item && typeof item.url === 'string').slice(0, 8) : [];
    } catch (_) { return []; }
  }

  function saveRecent(url, title) {
    try {
      const entries = [{url, title: title || url} , ...getRecents().filter(item => item.url !== url)].slice(0, 8);
      localStorage.setItem(RECENTS_KEY, JSON.stringify(entries));
    } catch (_) {}
  }

  function renderRecents() {
    const list = $('#recentSites');
    const items = getRecents();
    list.replaceChildren();
    if (!items.length) {
      const empty = document.createElement('p');
      empty.className = 'empty-state';
      empty.textContent = 'Pages you visit will show up here.';
      list.append(empty);
      return;
    }
    items.forEach(item => {
      let host = item.url;
      try { host = new URL(item.url).hostname.replace(/^www\./, ''); } catch (_) {}
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'recent-item';
      const icon = document.createElement('span'); icon.className = 'recent-favicon'; icon.textContent = '↗';
      const copy = document.createElement('span'); copy.className = 'recent-copy';
      const title = document.createElement('b'); title.textContent = item.title || host;
      const subtitle = document.createElement('small'); subtitle.textContent = host;
      copy.append(title, subtitle); button.append(icon, copy);
      button.addEventListener('click', () => location.href = `shorts://open?url=${encodeURIComponent(item.url)}`);
      list.append(button);
    });
  }

  $('#searchForm').addEventListener('submit', event => {
    event.preventDefault();
    searchOrOpen($('#searchInput').value);
  });
  $('#searchEngine').addEventListener('change', event => saveEngine(event.target.value));
  $('#settingsSearchEngine').addEventListener('change', event => saveEngine(event.target.value));
  $('#themeButton').addEventListener('click', setTheme);
  $('#themeSettingsButton').addEventListener('click', setTheme);
  $$('[data-panel]').forEach(button => button.addEventListener('click', () => showPanel(button.dataset.panel)));
  $$('[data-action="open-library"]').forEach(button => button.addEventListener('click', () => { location.href = 'shorts://library'; }));
  $$('[data-action="open-folder"]').forEach(button => button.addEventListener('click', () => { location.href = 'shorts://library?section=folder'; }));
  $$('[data-action="edit-shortcuts"]').forEach(button => button.addEventListener('click', () => toast('Quick links are set up for this version.')));
  $('#clearRecentSites').addEventListener('click', () => {
    try { localStorage.removeItem(RECENTS_KEY); } catch (_) {}
    renderRecents(); toast('Recently visited pages cleared.');
  });
  $('#clearHistoryButton').addEventListener('click', () => {
    try { localStorage.removeItem(RECENTS_KEY); } catch (_) {}
    renderRecents(); location.href = 'shorts://clearhistory';
  });
  $('#clearBrowserDataButton').addEventListener('click', () => { location.href = 'shorts://cleardata'; });
  document.addEventListener('click', event => {
    const anchor = event.target.closest('a[href]');
    if (!anchor || anchor.target === '_blank' || event.defaultPrevented || event.button !== 0) return;
    const href = anchor.getAttribute('href') || '';
    if (href.startsWith('shorts://')) { event.preventDefault(); location.href = href; }
  });
  function setNativeRecents(encoded) {
    try {
      const parsed = typeof encoded === 'string' ? JSON.parse(encoded) : encoded;
      if (Array.isArray(parsed)) localStorage.setItem(RECENTS_KEY, JSON.stringify(parsed.filter(item => item && typeof item.url === 'string').slice(0, 8)));
    } catch (_) {}
    renderRecents();
  }
  function setNativeSearchEngine(engine) {
    if (!validEngine(engine)) return;
    try { localStorage.setItem(ENGINE_KEY, engine); } catch (_) {}
    $('#searchEngine').value = engine;
    $('#settingsSearchEngine').value = engine;
  }
  window.ShortsBrowser = {saveRecent, showPanel, toast, setNativeRecents, setNativeSearchEngine};
  loadPreferences();
  renderRecents();
})();
