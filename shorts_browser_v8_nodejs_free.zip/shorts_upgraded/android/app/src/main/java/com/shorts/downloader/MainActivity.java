package com.shorts.downloader;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.text.InputType;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

/**
 * Standalone Android browser shell. The home page is bundled in the APK, so the browser
 * no longer needs a Python server or the old short-link/media-extractor workflow.
 */
public class MainActivity extends Activity {
    private static final String PREFS = "shorts_browser";
    private static final String KEY_ENGINE = "search_engine";
    private static final String KEY_BOOKMARKS = "browser_bookmarks_json";
    private static final String KEY_HISTORY = "browser_history_json";
    private static final String KEY_DESKTOP = "desktop_mode";
    private static final String APP_ASSET_ORIGIN = "https://appassets.androidplatform.net";
    private static final String HOME_URL = APP_ASSET_ORIGIN + "/assets/browser.html";
    private static final int MAX_SAVED_PAGES = 120;
    private static final int MAX_TABS = 12;
    private static final int REQ_WRITE_STORAGE = 31;
    private static final int REQ_NOTIFICATIONS = 32;

    private WebViewAssetLoader assetLoader;
    private WebView webView;
    private LinearLayout browserBar;
    private LinearLayout webContainer;
    private EditText addressInput;
    private final ArrayList<WebView> webTabs = new ArrayList<>();
    private final ArrayList<String> tabLabels = new ArrayList<>();
    private int activeTabIndex = 0;
    private View fullScreenView;
    private WebChromeClient.CustomViewCallback fullScreenCallback;
    private FrameLayout fullScreenContainer;
    private int previousSystemUiVisibility = 0;
    private boolean desktopMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11, 13, 19));
        getWindow().setNavigationBarColor(Color.rgb(11, 13, 19));
        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        desktopMode = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_DESKTOP, false);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(11, 13, 19));
        setContentView(root);

        browserBar = new LinearLayout(this);
        browserBar.setOrientation(LinearLayout.HORIZONTAL);
        browserBar.setGravity(Gravity.CENTER_VERTICAL);
        browserBar.setPadding(dp(4), dp(5), dp(4), dp(5));
        browserBar.setBackgroundColor(Color.rgb(20, 23, 32));
        root.addView(browserBar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54)));

        addBrowserButton("‹", "Back", () -> { if (webView != null && webView.canGoBack()) webView.goBack(); });
        addBrowserButton("›", "Forward", () -> { if (webView != null && webView.canGoForward()) webView.goForward(); });
        addBrowserButton("⌂", "Home", this::goHome);

        addressInput = new EditText(this);
        addressInput.setSingleLine(true);
        addressInput.setTextSize(13);
        addressInput.setTextColor(Color.rgb(237, 240, 247));
        addressInput.setHintTextColor(Color.rgb(143, 153, 171));
        addressInput.setHint("Search or enter website");
        addressInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        addressInput.setImeOptions(EditorInfo.IME_ACTION_GO);
        addressInput.setSelectAllOnFocus(true);
        addressInput.setPadding(dp(11), 0, dp(7), 0);
        GradientDrawable addressBackground = new GradientDrawable();
        addressBackground.setColor(Color.rgb(27, 32, 44));
        addressBackground.setCornerRadius(dp(13));
        addressBackground.setStroke(dp(1), Color.rgb(48, 55, 70));
        addressInput.setBackground(addressBackground);
        LinearLayout.LayoutParams addressParams = new LinearLayout.LayoutParams(0, dp(41), 1f);
        addressParams.setMargins(dp(2), 0, dp(2), 0);
        browserBar.addView(addressInput, addressParams);
        addressInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO
                    || (event != null && event.getKeyCode() == android.view.KeyEvent.KEYCODE_ENTER)) {
                navigateAddress();
                return true;
            }
            return false;
        });
        addBrowserButton("↻", "Reload page", () -> {
            if (webView != null) {
                if (isTrustedAppPage(webView.getUrl())) webView.loadUrl(HOME_URL);
                else webView.reload();
            }
        });
        addBrowserButton("▢", "Tabs", this::showTabsDialog);
        addBrowserButton("⋮", "Browser menu", this::showBrowserMenu);

        webContainer = new LinearLayout(this);
        webContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(webContainer, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        webView = createConfiguredWebView();
        webContainer.addView(webView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
        webTabs.add(webView);
        tabLabels.add("Shorts Browser");
        webView.loadUrl(HOME_URL);

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_WRITE_STORAGE);
        }
    }

    private WebView createConfiguredWebView() {
        WebView view = new WebView(this);
        view.setBackgroundColor(Color.rgb(11, 13, 19));
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) settings.setSafeBrowsingEnabled(true);
        applyUserAgent(settings);

        view.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View customView, CustomViewCallback callback) {
                showFullScreenVideo(customView, callback);
            }
            @Override public void onHideCustomView() { hideFullScreenVideo(); }
            @Override public boolean onCreateWindow(WebView source, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                if (!isUserGesture || webTabs.size() >= MAX_TABS) {
                    if (webTabs.size() >= MAX_TABS) toast("You have 12 tabs open. Close one first.");
                    return false;
                }
                WebView popup = createBlankBrowserTab();
                if (popup == null || !(resultMsg.obj instanceof WebView.WebViewTransport)) return false;
                ((WebView.WebViewTransport) resultMsg.obj).setWebView(popup);
                resultMsg.sendToTarget();
                return true;
            }
            @Override public void onReceivedTitle(WebView source, String title) {
                updateTabLabel(source);
            }
        });

        view.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView source, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView source, WebResourceRequest request) {
                Uri target = request.getUrl();
                String scheme = lower(target.getScheme());
                if ("shorts".equals(scheme)) {
                    if (isTrustedAppPage(source.getUrl())) handleBrowserCommand(target);
                    else toast("That app action is only available from Shorts Browser pages.");
                    return true;
                }
                if ("mailto".equals(scheme) || "tel".equals(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, target)); }
                    catch (Exception ignored) { toast("No installed app can open that link."); }
                    return true;
                }
                if ("intent".equals(scheme) || "file".equals(scheme) || "content".equals(scheme)) return true;
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    if (source == webView) updateBrowserBar(target);
                    return false;
                }
                return true;
            }
            @Override public void onPageFinished(WebView source, String url) {
                super.onPageFinished(source, url);
                updateTabLabel(source);
                Uri uri = safeUri(url);
                if (uri == null) return;
                if (source == webView) updateBrowserBar(uri);
                if (isHttpPage(uri) && !isTrustedAppPage(url)) {
                    addBrowserHistory(source, url);
                }
                if (isTrustedAppPage(url)) syncRecentSitesToHome(source);
            }
            @Override public void onReceivedError(WebView source, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) toast("This page couldn't be loaded. Check the connection and try again.");
            }
        });

        view.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) ->
                enqueueBrowserDownload(url, userAgent, contentDisposition, mimeType));
        return view;
    }

    private void applyUserAgent(WebSettings settings) {
        if (desktopMode) {
            settings.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36");
        } else {
            settings.setUserAgentString(null);
        }
    }

    private void navigateAddress() {
        String raw = addressInput == null ? "" : addressInput.getText().toString().trim();
        if (raw.isEmpty()) return;
        String target;
        if (raw.matches("(?i)^https?://.*")) target = raw;
        else if (!raw.contains(" ") && raw.matches("(?i)^(localhost|[a-z0-9-]+(?:\\.[a-z0-9-]+)+)(?::\\d+)?(?:/.*)?$")) target = "https://" + raw;
        else target = buildSearchUrl(raw, selectedSearchEngine());
        Uri uri = safeUri(target);
        if (uri == null || !isHttpPage(uri)) { toast("Enter a website address or a search term."); return; }
        addressInput.clearFocus();
        webView.loadUrl(target);
    }

    private String buildSearchUrl(String query, String engine) {
        String q = enc(query == null ? "" : query.trim());
        String safeEngine = (engine == null || engine.trim().isEmpty()) ? "google" : engine.trim().toLowerCase();
        switch (safeEngine) {
            case "bing": return "https://www.bing.com/search?q=" + q;
            case "brave": return "https://search.brave.com/search?q=" + q;
            case "duckduckgo": return "https://duckduckgo.com/?q=" + q;
            case "yahoo": return "https://search.yahoo.com/search?p=" + q;
            case "ecosia": return "https://www.ecosia.org/search?q=" + q;
            case "startpage": return "https://www.startpage.com/sp/search?query=" + q;
            case "ask": return "https://www.ask.com/web?q=" + q;
            case "yandex": return "https://yandex.com/search/?text=" + q;
            case "aol": return "https://search.aol.com/aol/search?q=" + q;
            case "qwant": return "https://www.qwant.com/?q=" + q;
            case "mojeek": return "https://www.mojeek.com/search?q=" + q;
            case "wikipedia": return "https://en.wikipedia.org/w/index.php?search=" + q;
            case "youtube": return "https://www.youtube.com/results?search_query=" + q;
            default: return "https://www.google.com/search?q=" + q;
        }
    }

    private String selectedSearchEngine() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_ENGINE, "google");
    }

    private void handleBrowserCommand(Uri command) {
        String action = lower(command.getHost());
        if ("search".equals(action)) {
            String query = command.getQueryParameter("q");
            if (query == null || query.trim().isEmpty()) { toast("Type something to search for."); return; }
            String engine = command.getQueryParameter("engine");
            if (engine == null || engine.isEmpty()) engine = selectedSearchEngine();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_ENGINE, engine).apply();
            webView.loadUrl(buildSearchUrl(query, engine));
            return;
        }
        if ("open".equals(action)) {
            String raw = command.getQueryParameter("url");
            Uri target = safeUri(raw);
            if (target == null || !isHttpPage(target)) { toast("That website address is not valid."); return; }
            webView.loadUrl(target.toString());
            return;
        }
        if ("library".equals(action)) {
            Intent intent = new Intent(this, LibraryActivity.class);
            String section = command.getQueryParameter("section");
            if (section != null) intent.putExtra("section", section);
            startActivity(intent);
            return;
        }
        if ("newtab".equals(action)) { createNewTab(HOME_URL); return; }
        if ("setsearch".equals(action)) {
            String engine = command.getQueryParameter("engine");
            if (!isSupportedEngine(engine)) { toast("That search site isn't supported."); return; }
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_ENGINE, engine).apply();
            return;
        }
        if ("clearhistory".equals(action)) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_HISTORY, "[]").apply();
            toast("Browsing history cleared.");
            return;
        }
        if ("cleardata".equals(action)) { showClearDataDialog(); return; }
        if ("home".equals(action)) { goHome(); return; }
        toast("This browser action isn't available.");
    }

    private boolean isSupportedEngine(String id) {
        if (id == null) return false;
        String[] values = {"google","bing","brave","duckduckgo","yahoo","ecosia","startpage","ask","yandex","aol","qwant","mojeek","wikipedia","youtube"};
        for (String value : values) if (value.equals(id)) return true;
        return false;
    }

    private void goHome() {
        if (webView == null) return;
        webView.loadUrl(HOME_URL);
        addressInput.clearFocus();
    }

    private WebView createBlankBrowserTab() {
        if (webTabs.size() >= MAX_TABS) return null;
        WebView next = createConfiguredWebView();
        next.setVisibility(View.GONE);
        webContainer.addView(next, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
        webTabs.add(next);
        tabLabels.add("New tab");
        switchToTab(webTabs.size() - 1);
        return next;
    }

    private void createNewTab(String initialUrl) {
        if (webTabs.size() >= MAX_TABS) { toast("You have 12 tabs open. Close one first."); return; }
        WebView next = createBlankBrowserTab();
        if (next == null) return;
        next.loadUrl(initialUrl == null ? HOME_URL : initialUrl);
    }

    private void switchToTab(int index) {
        if (index < 0 || index >= webTabs.size()) return;
        if (webView != null) webView.setVisibility(View.GONE);
        activeTabIndex = index;
        webView = webTabs.get(index);
        webView.setVisibility(View.VISIBLE);
        updateBrowserBar(safeUri(webView.getUrl()));
        invalidateOptionsMenu();
    }

    private void updateTabLabel(WebView source) {
        int index = webTabs.indexOf(source);
        if (index < 0) return;
        String title = source.getTitle();
        if (title == null || title.trim().isEmpty()) {
            Uri uri = safeUri(source.getUrl());
            title = uri == null || uri.getHost() == null ? "New tab" : uri.getHost();
        }
        tabLabels.set(index, title.trim());
        if (source == webView) invalidateOptionsMenu();
    }

    private void showTabsDialog() {
        if (webTabs.isEmpty()) { createNewTab(HOME_URL); return; }
        String[] labels = new String[webTabs.size()];
        for (int i = 0; i < webTabs.size(); i++) {
            Uri uri = safeUri(webTabs.get(i).getUrl());
            String label = (i + 1) + ". " + tabLabels.get(i);
            if (uri != null && uri.getHost() != null) label += " · " + uri.getHost();
            if (i == activeTabIndex) label = "✓  " + label;
            labels[i] = label;
        }
        new AlertDialog.Builder(this).setTitle("Open tabs · " + webTabs.size())
                .setItems(labels, (dialog, which) -> switchToTab(which))
                .setNeutralButton("New tab", (dialog, which) -> createNewTab(HOME_URL))
                .setNegativeButton("Close current", (dialog, which) -> closeCurrentTab()).show();
    }

    private void closeCurrentTab() {
        if (webTabs.size() <= 1) { goHome(); toast("Kept the last tab open."); return; }
        WebView closing = webTabs.remove(activeTabIndex);
        tabLabels.remove(activeTabIndex);
        webContainer.removeView(closing);
        closing.stopLoading(); closing.loadUrl("about:blank"); closing.removeAllViews(); closing.destroy();
        activeTabIndex = Math.min(activeTabIndex, webTabs.size() - 1);
        webView = null;
        switchToTab(activeTabIndex);
    }

    private void showSearchEngineDialog() {
        String[] labels = {"Google", "Bing", "Brave Search", "DuckDuckGo", "Yahoo", "Ecosia", "Startpage", "Ask", "Yandex", "AOL Search", "Qwant", "Mojeek", "Wikipedia", "YouTube"};
        String[] ids = {"google", "bing", "brave", "duckduckgo", "yahoo", "ecosia", "startpage", "ask", "yandex", "aol", "qwant", "mojeek", "wikipedia", "youtube"};
        String current = selectedSearchEngine();
        int checked = 0;
        for (int i = 0; i < ids.length; i++) if (ids[i].equals(current)) checked = i;
        new AlertDialog.Builder(this).setTitle("Default search engine")
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_ENGINE, ids[which]).apply();
                    webView.evaluateJavascript("try{localStorage.setItem('shorts-browser-search-engine-v1'," + JSONObject.quote(ids[which]) + ");document.querySelector('#searchEngine').value=" + JSONObject.quote(ids[which]) + ";document.querySelector('#settingsSearchEngine').value=" + JSONObject.quote(ids[which]) + ";}catch(e){}", null);
                    dialog.dismiss(); toast("Search engine set to " + labels[which]);
                }).setNegativeButton("Cancel", null).show();
    }

    private void showBrowserMenu() {
        String[] items = {"Open library", "Open downloads", "New tab", "Open tabs", "Close current tab", "Default search engine", "Bookmark this page", "Bookmarks", "Browsing history", desktopMode ? "Use mobile websites" : "Request desktop websites", "Clear website data"};
        new AlertDialog.Builder(this).setTitle("Shorts Browser").setItems(items, (dialog, which) -> {
            switch (which) {
                case 0: openLibrary("all"); break;
                case 1: openLibrary("downloads"); break;
                case 2: createNewTab(HOME_URL); break;
                case 3: showTabsDialog(); break;
                case 4: closeCurrentTab(); break;
                case 5: showSearchEngineDialog(); break;
                case 6: addBookmark(); break;
                case 7: showSavedPagesDialog(KEY_BOOKMARKS, "Bookmarks", false); break;
                case 8: showSavedPagesDialog(KEY_HISTORY, "Browsing history", true); break;
                case 9: toggleDesktopMode(); break;
                case 10: showClearDataDialog(); break;
            }
        }).show();
    }

    private void openLibrary(String section) {
        Intent intent = new Intent(this, LibraryActivity.class);
        intent.putExtra("section", section == null ? "all" : section);
        startActivity(intent);
    }

    private void toggleDesktopMode() {
        desktopMode = !desktopMode;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_DESKTOP, desktopMode).apply();
        for (WebView view : webTabs) { applyUserAgent(view.getSettings()); view.reload(); }
        toast(desktopMode ? "Desktop websites requested." : "Mobile websites requested.");
    }

    private void showClearDataDialog() {
        new AlertDialog.Builder(this).setTitle("Clear website data?")
                .setMessage("This clears saved cookies, website storage and page cache. It can sign you out of websites. Bookmarks and local files are kept.")
                .setPositiveButton("Clear data", (dialog, which) -> {
                    CookieManager.getInstance().removeAllCookies(null);
                    CookieManager.getInstance().flush();
                    WebStorage.getInstance().deleteAllData();
                    for (WebView view : webTabs) { view.clearCache(true); view.clearFormData(); }
                    toast("Website data cleared.");
                }).setNegativeButton("Cancel", null).show();
    }

    private void addBookmark() {
        if (webView == null) return;
        String pageUrl = webView.getUrl();
        Uri uri = safeUri(pageUrl);
        if (uri == null || !isHttpPage(uri)) { toast("Open a website before bookmarking it."); return; }
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        JSONArray old = readArray(prefs.getString(KEY_BOOKMARKS, "[]"));
        JSONArray next = new JSONArray();
        JSONObject item = new JSONObject();
        try { item.put("url", pageUrl); item.put("title", cleanTitle(webView.getTitle(), uri.getHost())); next.put(item); } catch (Exception ignored) {}
        for (int i = 0; i < old.length() && next.length() < MAX_SAVED_PAGES; i++) {
            JSONObject saved = old.optJSONObject(i);
            if (saved == null || pageUrl.equals(saved.optString("url", ""))) continue;
            next.put(saved);
        }
        prefs.edit().putString(KEY_BOOKMARKS, next.toString()).apply();
        toast("Bookmark saved.");
    }

    private void addBrowserHistory(WebView source, String rawUrl) {
        Uri uri = safeUri(rawUrl);
        if (source == null || uri == null || !isHttpPage(uri)) return;
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        JSONArray old = readArray(prefs.getString(KEY_HISTORY, "[]"));
        JSONArray next = new JSONArray();
        JSONObject current = new JSONObject();
        try { current.put("url", rawUrl); current.put("title", cleanTitle(source.getTitle(), uri.getHost())); current.put("time", System.currentTimeMillis()); next.put(current); }
        catch (Exception ignored) {}
        for (int i = 0; i < old.length() && next.length() < MAX_SAVED_PAGES; i++) {
            JSONObject saved = old.optJSONObject(i);
            if (saved == null || rawUrl.equals(saved.optString("url", ""))) continue;
            next.put(saved);
        }
        prefs.edit().putString(KEY_HISTORY, next.toString()).apply();
    }

    private void syncRecentSitesToHome(WebView source) {
        JSONArray history = readArray(getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_HISTORY, "[]"));
        JSONArray recent = new JSONArray();
        for (int i = 0; i < history.length() && recent.length() < 8; i++) {
            JSONObject item = history.optJSONObject(i);
            if (item == null) continue;
            String url = item.optString("url", "");
            Uri uri = safeUri(url);
            if (uri == null || !isHttpPage(uri)) continue;
            try { recent.put(new JSONObject().put("url", url).put("title", item.optString("title", uri.getHost()))); }
            catch (Exception ignored) {}
        }
        String engine = JSONObject.quote(selectedSearchEngine());
        source.evaluateJavascript("if(window.ShortsBrowser){window.ShortsBrowser.setNativeSearchEngine(" + engine + ");window.ShortsBrowser.setNativeRecents(" + JSONObject.quote(recent.toString()) + ");}", null);
    }

    private void showSavedPagesDialog(String prefKey, String title, boolean clearable) {
        JSONArray saved = readArray(getSharedPreferences(PREFS, MODE_PRIVATE).getString(prefKey, "[]"));
        if (saved.length() == 0) {
            new AlertDialog.Builder(this).setTitle(title).setMessage(prefKey.equals(KEY_BOOKMARKS)
                    ? "Pages you bookmark will appear here." : "Websites you visit will appear here.").setPositiveButton("OK", null).show();
            return;
        }
        JSONArray items = new JSONArray();
        ArrayList<String> labels = new ArrayList<>();
        for (int i = 0; i < saved.length(); i++) {
            JSONObject item = saved.optJSONObject(i);
            if (item == null) continue;
            String url = item.optString("url", "");
            Uri uri = safeUri(url);
            String label = item.optString("title", "Saved page");
            if (uri != null && uri.getHost() != null) label += " · " + uri.getHost();
            labels.add(label); items.put(item);
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this).setTitle(title)
                .setItems(labels.toArray(new String[0]), (dialog, which) -> {
                    JSONObject item = items.optJSONObject(which);
                    if (item == null) return;
                    Uri target = safeUri(item.optString("url", ""));
                    if (target != null && isHttpPage(target)) webView.loadUrl(target.toString());
                }).setNegativeButton("Close", null);
        if (clearable) builder.setNeutralButton("Clear history", (dialog, which) -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_HISTORY, "[]").apply();
            toast("Browsing history cleared.");
        });
        builder.show();
    }

    private void enqueueBrowserDownload(String url, String userAgent, String contentDisposition, String mimeType) {
        Uri uri = safeUri(url);
        if (uri == null || !isHttpPage(uri)) { toast("This download link isn't supported."); return; }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_WRITE_STORAGE);
            toast("Allow storage access, then tap the download link again.");
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
        try {
            String name = URLUtil.guessFileName(url, contentDisposition, mimeType);
            name = name.replaceAll("[\\\\/\\r\\n\\t]", "_").trim();
            if (name.isEmpty() || ".".equals(name) || "..".equals(name)) name = "download";
            DownloadManager.Request request = new DownloadManager.Request(uri);
            request.setTitle(name);
            request.setDescription("Downloading with Shorts Browser");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(false);
            if (mimeType != null && !mimeType.trim().isEmpty()) request.setMimeType(mimeType);
            if (userAgent != null && !userAgent.trim().isEmpty()) request.addRequestHeader("User-Agent", userAgent);
            String cookies = CookieManager.getInstance().getCookie(url);
            if (cookies != null && !cookies.isEmpty()) request.addRequestHeader("Cookie", cookies);
            String referer = webView == null ? null : webView.getUrl();
            if (referer != null && isHttpPage(safeUri(referer))) request.addRequestHeader("Referer", referer);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            if (manager == null) throw new IllegalStateException("Android download service is unavailable.");
            manager.enqueue(request);
            toast("Download started. Check the Library → Downloads tab.");
        } catch (Exception e) {
            toast("Could not start this download. Try the website's own download button.");
        }
    }

    private void updateBrowserBar(Uri target) {
        if (addressInput == null) return;
        runOnUiThread(() -> {
            if (addressInput.hasFocus()) return;
            if (target == null || isTrustedAppPage(target.toString())) {
                addressInput.setText("");
                addressInput.setHint("Search or enter website");
            } else {
                addressInput.setHint("Search or enter website");
                addressInput.setText(target.toString());
            }
        });
    }

    private void addBrowserButton(String glyph, String description, Runnable action) {
        TextView button = new TextView(this);
        button.setText(glyph); button.setTextSize(22); button.setTextColor(Color.rgb(206, 211, 225));
        button.setGravity(Gravity.CENTER); button.setContentDescription(description); button.setFocusable(true); button.setClickable(true);
        button.setPadding(dp(3), 0, dp(3), 0);
        browserBar.addView(button, new LinearLayout.LayoutParams(dp(29), dp(42)));
        button.setOnClickListener(v -> action.run());
    }

    private void showFullScreenVideo(View customView, WebChromeClient.CustomViewCallback callback) {
        if (fullScreenView != null) { callback.onCustomViewHidden(); return; }
        fullScreenView = customView; fullScreenCallback = callback;
        View decor = getWindow().getDecorView();
        previousSystemUiVisibility = decor.getSystemUiVisibility();
        fullScreenContainer = new FrameLayout(this); fullScreenContainer.setBackgroundColor(Color.BLACK);
        fullScreenContainer.addView(customView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        ((FrameLayout) decor).addView(fullScreenContainer, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    private void hideFullScreenVideo() {
        if (fullScreenView == null) return;
        try {
            View decor = getWindow().getDecorView();
            if (fullScreenContainer != null && fullScreenContainer.getParent() == decor) ((FrameLayout) decor).removeView(fullScreenContainer);
            decor.setSystemUiVisibility(previousSystemUiVisibility);
        } catch (Exception ignored) {}
        try { if (fullScreenCallback != null) fullScreenCallback.onCustomViewHidden(); } catch (Exception ignored) {}
        fullScreenView = null; fullScreenCallback = null; fullScreenContainer = null;
    }

    @Override public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 1, 0, "Library"); menu.add(0, 2, 1, "Downloads"); menu.add(0, 3, 2, "New tab");
        menu.add(0, 4, 3, "Tabs (" + webTabs.size() + ")"); menu.add(0, 5, 4, "Close current tab");
        menu.add(0, 6, 5, "Search engine"); menu.add(0, 7, 6, "Bookmark this page");
        menu.add(0, 8, 7, "Bookmarks"); menu.add(0, 9, 8, "History");
        menu.add(0, 10, 9, desktopMode ? "Use mobile websites" : "Request desktop websites");
        menu.add(0, 11, 10, "Clear website data");
        return true;
    }

    @Override public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 1: openLibrary("all"); return true;
            case 2: openLibrary("downloads"); return true;
            case 3: createNewTab(HOME_URL); return true;
            case 4: showTabsDialog(); return true;
            case 5: closeCurrentTab(); return true;
            case 6: showSearchEngineDialog(); return true;
            case 7: addBookmark(); return true;
            case 8: showSavedPagesDialog(KEY_BOOKMARKS, "Bookmarks", false); return true;
            case 9: showSavedPagesDialog(KEY_HISTORY, "Browsing history", true); return true;
            case 10: toggleDesktopMode(); return true;
            case 11: showClearDataDialog(); return true;
            default: return super.onOptionsItemSelected(item);
        }
    }

    @Override public void onBackPressed() {
        if (fullScreenView != null) { hideFullScreenVideo(); return; }
        if (webView != null && webView.canGoBack()) { webView.goBack(); return; }
        if (webTabs.size() > 1) { closeCurrentTab(); return; }
        if (webView != null && !isTrustedAppPage(webView.getUrl())) { goHome(); return; }
        super.onBackPressed();
    }

    private boolean isTrustedAppPage(String rawUrl) {
        Uri uri = safeUri(rawUrl);
        return uri != null && "https".equalsIgnoreCase(uri.getScheme())
                && "appassets.androidplatform.net".equalsIgnoreCase(uri.getHost())
                && uri.getPath() != null && uri.getPath().startsWith("/assets/");
    }
    private boolean isTrustedAppPage(Uri uri) { return uri != null && isTrustedAppPage(uri.toString()); }
    private boolean isHttpPage(Uri uri) { return uri != null && ("http".equalsIgnoreCase(uri.getScheme()) || "https".equalsIgnoreCase(uri.getScheme())); }
    private Uri safeUri(String value) { try { return value == null || value.trim().isEmpty() ? null : Uri.parse(value.trim()); } catch (Exception ignored) { return null; } }
    private String lower(String value) { return value == null ? "" : value.toLowerCase(); }
    private String enc(String value) { try { return URLEncoder.encode(value, "UTF-8"); } catch (UnsupportedEncodingException ignored) { return value; } }
    private String cleanTitle(String value, String fallback) { return value == null || value.trim().isEmpty() ? fallback : value.trim(); }
    private JSONArray readArray(String raw) { try { return new JSONArray(raw); } catch (Exception ignored) { return new JSONArray(); } }
    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIFICATIONS && grantResults.length > 0 && grantResults[0] != PackageManager.PERMISSION_GRANTED) {
            toast("Downloads still work, but Android may not show download notifications.");
        }
    }

    private void toast(String message) { runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show()); }
}
