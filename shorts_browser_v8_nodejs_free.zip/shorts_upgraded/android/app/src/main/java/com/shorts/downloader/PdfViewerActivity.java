package com.shorts.downloader;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Lightweight in-app PDF viewer. It renders one page at a time to avoid retaining every page bitmap. */
public class PdfViewerActivity extends Activity {
    private PdfRenderer renderer;
    private ParcelFileDescriptor descriptor;
    private ImageView image;
    private TextView pageLabel;
    private int pageIndex = 0;
    private int renderSequence = 0;
    private Bitmap displayedBitmap;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11, 13, 19)); getWindow().setNavigationBarColor(Color.rgb(11, 13, 19));
        Uri uri = getIntent().getData();
        if (uri == null) { finish(); return; }
        String title = getIntent().getStringExtra("displayName");
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(11, 13, 19)); setContentView(root);
        LinearLayout toolbar = new LinearLayout(this); toolbar.setGravity(Gravity.CENTER_VERTICAL); toolbar.setPadding(dp(8), dp(5), dp(8), dp(5));
        TextView back = text("‹", 29, Color.WHITE, true); back.setGravity(Gravity.CENTER); toolbar.addView(back, new LinearLayout.LayoutParams(dp(38), dp(42))); back.setOnClickListener(v -> finish());
        TextView heading = text(title == null ? "PDF document" : title, 13, Color.WHITE, true); heading.setMaxLines(1); heading.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, -2, 1f); titleLp.setMargins(dp(5), 0, dp(5), 0); toolbar.addView(heading, titleLp);
        root.addView(toolbar);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(Color.rgb(30, 32, 39));
        image = new ImageView(this); image.setAdjustViewBounds(true); image.setScaleType(ImageView.ScaleType.FIT_CENTER); image.setPadding(dp(7), dp(8), dp(7), dp(8)); scroll.addView(image, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout controls = new LinearLayout(this); controls.setGravity(Gravity.CENTER); controls.setPadding(dp(12), dp(8), dp(12), dp(8));
        Button previous = new Button(this); previous.setText("‹ Previous"); previous.setTextSize(12); controls.addView(previous, new LinearLayout.LayoutParams(0, dp(44), 1f));
        pageLabel = text("Page 1", 12, Color.WHITE, true); pageLabel.setGravity(Gravity.CENTER); controls.addView(pageLabel, new LinearLayout.LayoutParams(dp(90), -2));
        Button next = new Button(this); next.setText("Next ›"); next.setTextSize(12); controls.addView(next, new LinearLayout.LayoutParams(0, dp(44), 1f));
        root.addView(controls);
        previous.setOnClickListener(v -> showPage(pageIndex - 1)); next.setOnClickListener(v -> showPage(pageIndex + 1));
        try { descriptor = getContentResolver().openFileDescriptor(uri, "r"); if (descriptor == null) throw new IOException("No file handle"); renderer = new PdfRenderer(descriptor); showPage(0); }
        catch (Exception e) { Toast.makeText(this, "This PDF couldn't be opened. It may be protected or damaged.", Toast.LENGTH_LONG).show(); finish(); }
    }

    private void showPage(int requested) {
        if (renderer == null || requested < 0 || requested >= renderer.getPageCount()) return;
        pageIndex = requested; pageLabel.setText("Page " + (pageIndex + 1) + " / " + renderer.getPageCount());
        final int requestId = ++renderSequence;
        image.setImageDrawable(null);
        if (displayedBitmap != null && !displayedBitmap.isRecycled()) displayedBitmap.recycle();
        displayedBitmap = null;
        worker.execute(() -> {
            Bitmap bitmap = null;
            try (PdfRenderer.Page page = renderer.openPage(requested)) {
                int screen = Math.max(1, getResources().getDisplayMetrics().widthPixels - dp(30));
                double pagePixels = (double) page.getWidth() * (double) page.getHeight();
                float fitWidth = (float) screen / (float) page.getWidth();
                float memoryBound = (float) Math.sqrt(6_000_000d / Math.max(1d, pagePixels));
                float scale = Math.min(2.0f, Math.min(fitWidth, memoryBound));
                scale = Math.max(0.001f, scale);
                int width = Math.max(1, Math.round(page.getWidth() * scale));
                int height = Math.max(1, Math.round(page.getHeight() * scale));
                bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                bitmap.eraseColor(Color.WHITE);
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            } catch (Exception ignored) {}
            final Bitmap rendered = bitmap;
            runOnUiThread(() -> {
                if (isFinishing() || requestId != renderSequence) {
                    if (rendered != null && !rendered.isRecycled()) rendered.recycle();
                    return;
                }
                if (rendered == null) { Toast.makeText(this, "Couldn't render this page.", Toast.LENGTH_SHORT).show(); return; }
                displayedBitmap = rendered;
                image.setImageBitmap(rendered);
            });
        });
    }
    private TextView text(String value, float size, int color, boolean bold) { TextView v = new TextView(this); v.setText(value); v.setTextSize(size); v.setTextColor(color); if (bold) v.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD); return v; }
    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    @Override protected void onDestroy() {
        renderSequence++;
        worker.shutdownNow();
        if (image != null) image.setImageDrawable(null);
        if (displayedBitmap != null && !displayedBitmap.isRecycled()) displayedBitmap.recycle();
        displayedBitmap = null;
        if (renderer != null) { try { renderer.close(); } catch (Exception ignored) {} renderer = null; }
        if (descriptor != null) { try { descriptor.close(); } catch (Exception ignored) {} descriptor = null; }
        super.onDestroy();
    }
}
