package com.shorts.downloader;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/** Simple built-in audio player with seek and play/pause controls. */
public class MusicPlayerActivity extends Activity {
    private MediaPlayer player;
    private SeekBar seek;
    private TextView time;
    private Button playButton;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean ready = false;
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (player != null && ready) {
                try { seek.setProgress(player.getCurrentPosition()); time.setText(format(player.getCurrentPosition()) + " / " + format(player.getDuration())); }
                catch (Exception ignored) {}
                handler.postDelayed(this, 500);
            }
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11, 13, 19)); getWindow().setNavigationBarColor(Color.rgb(11, 13, 19));
        Uri uri = getIntent().getData();
        String title = getIntent().getStringExtra("displayName");
        if (uri == null) { finish(); return; }
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(22), dp(24), dp(22), dp(24)); root.setBackgroundColor(Color.rgb(11, 13, 19)); setContentView(root);
        TextView top = text("NOW PLAYING", 10, Color.rgb(174, 160, 255), true); top.setLetterSpacing(.15f); root.addView(top);
        TextView art = text("♫", 62, Color.WHITE, true); art.setGravity(Gravity.CENTER);
        GradientDrawable cover = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Color.rgb(101, 79, 229), Color.rgb(161, 62, 223)}); cover.setCornerRadius(dp(30));
        art.setBackground(cover); LinearLayout.LayoutParams artLp = new LinearLayout.LayoutParams(dp(210), dp(210)); artLp.setMargins(0, dp(28), 0, dp(25)); root.addView(art, artLp);
        TextView heading = text(title == null ? "Your music" : title, 19, Color.WHITE, true); heading.setGravity(Gravity.CENTER); heading.setMaxLines(2); root.addView(heading);
        TextView subtitle = text("Playing from your library", 12, Color.rgb(145, 155, 173), false); subtitle.setGravity(Gravity.CENTER); LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2); subLp.setMargins(0, dp(8), 0, dp(25)); root.addView(subtitle, subLp);
        seek = new SeekBar(this); root.addView(seek, new LinearLayout.LayoutParams(-1, -2));
        time = text("0:00 / 0:00", 11, Color.rgb(145, 155, 173), false); time.setGravity(Gravity.CENTER); root.addView(time);
        playButton = new Button(this); playButton.setText("Play"); playButton.setTextSize(14); playButton.setTextColor(Color.WHITE); playButton.setBackground(cover); LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(dp(160), dp(48)); btnLp.setMargins(0, dp(24), 0, 0); root.addView(playButton, btnLp); playButton.setEnabled(false);
        playButton.setOnClickListener(v -> togglePlayback());
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) { if (fromUser && player != null && ready) { player.seekTo(progress); time.setText(format(progress) + " / " + format(player.getDuration())); } }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });
        try {
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            player.setDataSource(this, uri);
            player.setOnPreparedListener(mp -> { ready = true; seek.setMax(mp.getDuration()); playButton.setEnabled(true); playButton.setText("Pause"); mp.start(); handler.post(ticker); });
            player.setOnCompletionListener(mp -> { playButton.setText("Play again"); seek.setProgress(0); });
            player.setOnErrorListener((mp, what, extra) -> { Toast.makeText(this, "This audio format couldn't be played.", Toast.LENGTH_LONG).show(); finish(); return true; });
            player.prepareAsync();
        } catch (Exception e) { Toast.makeText(this, "Couldn't open this audio file.", Toast.LENGTH_LONG).show(); finish(); }
    }
    private void togglePlayback() {
        if (player == null || !ready) return;
        try { if (player.isPlaying()) { player.pause(); playButton.setText("Play"); } else { player.start(); playButton.setText("Pause"); handler.removeCallbacks(ticker); handler.post(ticker); } }
        catch (Exception ignored) { Toast.makeText(this, "Playback couldn't continue.", Toast.LENGTH_SHORT).show(); }
    }
    private TextView text(String value, float size, int color, boolean bold) { TextView v = new TextView(this); v.setText(value); v.setTextSize(size); v.setTextColor(color); if (bold) v.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD); return v; }
    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private String format(int ms) { int sec = Math.max(0, ms / 1000); return String.format(Locale.getDefault(), "%d:%02d", sec / 60, sec % 60); }
    @Override protected void onDestroy() { handler.removeCallbacksAndMessages(null); if (player != null) { try { player.stop(); } catch (Exception ignored) {} player.release(); player = null; } super.onDestroy(); }
}
