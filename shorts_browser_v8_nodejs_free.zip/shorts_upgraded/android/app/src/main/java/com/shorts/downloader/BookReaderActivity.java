package com.shorts.downloader;

import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.xml.parsers.DocumentBuilderFactory;

/** Built-in reader for text files and EPUB novels. */
public class BookReaderActivity extends Activity {
    private static final String PREFS = "shorts_browser_reader";
    private TextView body;
    private ScrollView scroll;
    private float fontSize = 18f;
    private volatile boolean destroyed = false;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11, 13, 19)); getWindow().setNavigationBarColor(Color.rgb(11, 13, 19));
        Uri uri = getIntent().getData(); if (uri == null) { finish(); return; }
        String name = getIntent().getStringExtra("displayName"); if (name == null) name = "Book";
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(13, 15, 21)); setContentView(root);
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(dp(10), dp(6), dp(10), dp(6));
        TextView back = text("‹", 28, Color.WHITE, true); back.setGravity(Gravity.CENTER); header.addView(back, new LinearLayout.LayoutParams(dp(35), dp(42))); back.setOnClickListener(v -> finish());
        TextView title = text(name, 13, Color.WHITE, true); title.setMaxLines(1); title.setEllipsize(android.text.TextUtils.TruncateAt.END); header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        Button smaller = new Button(this); smaller.setText("A−"); smaller.setTextSize(11); header.addView(smaller, new LinearLayout.LayoutParams(dp(48), dp(42)));
        Button larger = new Button(this); larger.setText("A+"); larger.setTextSize(11); header.addView(larger, new LinearLayout.LayoutParams(dp(48), dp(42)));
        root.addView(header);
        scroll = new ScrollView(this); scroll.setFillViewport(true); body = text("Opening book…", 18, Color.rgb(234, 236, 242), false); body.setTextIsSelectable(true); body.setLineSpacing(dp(6), 1.05f); body.setPadding(dp(22), dp(22), dp(22), dp(30)); scroll.addView(body); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        smaller.setOnClickListener(v -> changeFont(-1.5f)); larger.setOnClickListener(v -> changeFont(1.5f));
        try { fontSize = getSharedPreferences(PREFS, MODE_PRIVATE).getFloat("font_size", 18f); body.setTextSize(fontSize); } catch (Exception ignored) {}
        final String bookName = name;
        new Thread(() -> {
            String contents;
            try { contents = readBook(uri, bookName); }
            catch (Exception e) { contents = "This book couldn't be opened. Try a plain TXT or EPUB file."; }
            final String text = contents;
            runOnUiThread(() -> {
                if (destroyed || isFinishing() || isDestroyed()) return;
                body.setText(text);
                body.setTextSize(fontSize);
                restoreProgress(uri);
            });
        }).start();
    }

    private String readBook(Uri uri, String name) throws Exception {
        String lower = name.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".epub")) return readEpub(uri);
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IllegalStateException("No readable stream");
            byte[] bytes = readLimited(in, 16 * 1024 * 1024);
            String text = new String(bytes, StandardCharsets.UTF_8);
            if (lower.endsWith(".html") || lower.endsWith(".htm")) {
                String html = text.replaceAll("(?is)<(script|style)[^>]*>.*?</\\1>", " ");
                return Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString().trim();
            }
            return text.replace("\u0000", "").trim();
        }
    }

    private String readEpub(Uri uri) throws Exception {
        // EPUB files can contain large images and font files. Read only the package index
        // and chapter documents instead of retaining every ZIP entry in memory.
        byte[] containerBytes = findZipEntry(uri, "META-INF/container.xml", 512 * 1024);
        String container = new String(containerBytes, StandardCharsets.UTF_8);
        java.util.regex.Matcher pathMatch = java.util.regex.Pattern
                .compile("full-path\\s*=\\s*[\"']([^\"']+)[\"']", java.util.regex.Pattern.CASE_INSENSITIVE)
                .matcher(container);
        if (!pathMatch.find()) throw new IllegalStateException("EPUB book package was not found.");

        String opfPath = normalizeZipPath(pathMatch.group(1));
        byte[] opfBytes = findZipEntry(uri, opfPath, 4 * 1024 * 1024);
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        try { factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true); } catch (Exception ignored) {}
        try { factory.setFeature("http://xml.org/sax/features/external-general-entities", false); } catch (Exception ignored) {}
        try { factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false); } catch (Exception ignored) {}
        factory.setXIncludeAware(false);
        factory.setExpandEntityReferences(false);
        Document opf = factory.newDocumentBuilder().parse(new ByteArrayInputStream(opfBytes));

        Map<String, String> manifest = new LinkedHashMap<>();
        NodeList itemNodes = opf.getElementsByTagNameNS("*", "item");
        if (itemNodes.getLength() == 0) itemNodes = opf.getElementsByTagName("item");
        for (int i = 0; i < itemNodes.getLength(); i++) {
            Element e = (Element) itemNodes.item(i);
            String id = e.getAttribute("id");
            String href = e.getAttribute("href");
            String media = e.getAttribute("media-type");
            if (!id.isEmpty() && !href.isEmpty()
                    && (media.contains("html") || href.matches("(?i).*\\.(xhtml|html|htm)$"))) {
                manifest.put(id, href.split("#", 2)[0].split("\\?", 2)[0]);
            }
        }

        String base = "";
        int slash = opfPath.lastIndexOf('/');
        if (slash >= 0) base = opfPath.substring(0, slash + 1);
        ArrayList<String> orderedPaths = new ArrayList<>();
        NodeList refs = opf.getElementsByTagNameNS("*", "itemref");
        if (refs.getLength() == 0) refs = opf.getElementsByTagName("itemref");
        for (int i = 0; i < refs.getLength(); i++) {
            Element e = (Element) refs.item(i);
            String href = manifest.get(e.getAttribute("idref"));
            if (href != null) orderedPaths.add(normalizeZipPath(base + href));
        }
        if (orderedPaths.isEmpty()) throw new IllegalStateException("No readable chapters were found in this EPUB.");

        Set<String> wanted = new LinkedHashSet<>(orderedPaths);
        Map<String, String> chapterHtml = readSelectedZipEntries(uri, wanted);
        StringBuilder result = new StringBuilder();
        for (String path : orderedPaths) {
            String html = chapterHtml.get(path);
            if (html == null || html.trim().isEmpty()) continue;
            html = html.replaceAll("(?is)<(script|style)[^>]*>.*?</\\1>", " ");
            String chapter = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString().trim();
            if (!chapter.isEmpty()) {
                if (result.length() + chapter.length() > 1_500_000) {
                    throw new IllegalStateException("This book is too long to display in the lightweight reader.");
                }
                result.append(chapter).append("\n\n\n");
            }
        }
        if (result.length() == 0) throw new IllegalStateException("No readable chapters were found in this EPUB.");
        return result.toString().trim();
    }

    private byte[] findZipEntry(Uri uri, String wantedName, int maximumBytes) throws Exception {
        try (InputStream raw = getContentResolver().openInputStream(uri)) {
            if (raw == null) throw new IllegalStateException("This EPUB file can't be read.");
            try (ZipInputStream zip = new ZipInputStream(raw)) {
                ZipEntry entry;
                while ((entry = zip.getNextEntry()) != null) {
                    if (wantedName.equals(entry.getName())) {
                        return readLimited(zip, maximumBytes);
                    }
                    zip.closeEntry();
                }
            }
        }
        throw new IllegalStateException("EPUB metadata is missing: " + wantedName);
    }

    private Map<String, String> readSelectedZipEntries(Uri uri, Set<String> wantedPaths) throws Exception {
        Map<String, String> found = new LinkedHashMap<>();
        long totalBytes = 0;
        final int maximumEntryBytes = 2 * 1024 * 1024;
        final long maximumTotalBytes = 12L * 1024L * 1024L;
        try (InputStream raw = getContentResolver().openInputStream(uri)) {
            if (raw == null) throw new IllegalStateException("This EPUB file can't be read.");
            try (ZipInputStream zip = new ZipInputStream(raw)) {
                ZipEntry entry;
                while ((entry = zip.getNextEntry()) != null) {
                    if (entry.isDirectory() || !wantedPaths.contains(normalizeZipPath(entry.getName()))) continue;
                    byte[] bytes = readLimited(zip, maximumEntryBytes);
                    totalBytes += bytes.length;
                    if (totalBytes > maximumTotalBytes) throw new IllegalStateException("This EPUB is too large for the lightweight reader.");
                    found.put(normalizeZipPath(entry.getName()), new String(bytes, StandardCharsets.UTF_8));
                    if (found.size() == wantedPaths.size()) break;
                }
            }
        }
        return found;
    }

    private String normalizeZipPath(String path) {
        java.util.ArrayDeque<String> parts = new java.util.ArrayDeque<>();
        for (String part : path.replace('\\','/').split("/")) {
            if (part.isEmpty() || ".".equals(part)) continue;
            if ("..".equals(part)) { if (!parts.isEmpty()) parts.removeLast(); }
            else parts.addLast(part);
        }
        return String.join("/", parts);
    }
    private byte[] readLimited(InputStream in, int limit) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] buffer = new byte[8192]; int read; int total = 0;
        while ((read = in.read(buffer)) != -1) { total += read; if (total > limit) throw new IllegalStateException("This text file is too large to open."); out.write(buffer, 0, read); }
        return out.toByteArray();
    }
    private void changeFont(float delta) {
        fontSize = Math.max(13f, Math.min(30f, fontSize + delta)); body.setTextSize(fontSize);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putFloat("font_size", fontSize).apply();
    }
    private void saveProgress(Uri uri) {
        if (scroll == null || uri == null) return;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(uri.toString(), scroll.getScrollY()).apply();
    }
    private void restoreProgress(Uri uri) {
        if (uri == null) return;
        int y = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(uri.toString(), 0);
        scroll.post(() -> scroll.scrollTo(0, y));
    }
    private TextView text(String value, float size, int color, boolean bold) { TextView v = new TextView(this); v.setText(value); v.setTextSize(size); v.setTextColor(color); if (bold) v.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD); return v; }
    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    @Override protected void onPause() { saveProgress(getIntent().getData()); super.onPause(); }
    @Override protected void onDestroy() { destroyed = true; saveProgress(getIntent().getData()); super.onDestroy(); }
}
