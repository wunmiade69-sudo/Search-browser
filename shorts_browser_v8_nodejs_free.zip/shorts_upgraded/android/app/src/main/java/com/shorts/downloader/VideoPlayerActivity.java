package com.shorts.downloader;

import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

/** Built-in player for videos and films stored locally or selected through Android's file picker. */
public class VideoPlayerActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        String title = getIntent().getStringExtra("displayName");
        Uri uri = getIntent().getData();
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);
        if (uri == null) { finish(); return; }

        TextView heading = new TextView(this);
        heading.setText(title == null ? "Video" : title);
        heading.setTextColor(Color.WHITE); heading.setTextSize(14); heading.setMaxLines(1);
        heading.setEllipsize(android.text.TextUtils.TruncateAt.END);
        heading.setPadding(dp(14), dp(12), dp(14), dp(12));
        FrameLayout.LayoutParams headingParams = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp(48), Gravity.TOP);
        root.addView(heading, headingParams);

        VideoView player = new VideoView(this);
        FrameLayout.LayoutParams playerParams = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        playerParams.topMargin = dp(48); root.addView(player, playerParams);
        MediaController controller = new MediaController(this);
        controller.setAnchorView(player);
        player.setMediaController(controller);
        player.setVideoURI(uri);
        player.setOnPreparedListener(media -> { media.setOnVideoSizeChangedListener((mp, width, height) -> controller.setAnchorView(player)); player.start(); });
        player.setOnErrorListener((mediaPlayer, what, extra) -> {
            new android.app.AlertDialog.Builder(this).setTitle("Can't play this video")
                    .setMessage("This file format may not be supported by the built-in player.")
                    .setPositiveButton("OK", (d, w) -> finish()).show();
            return true;
        });
    }
    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
