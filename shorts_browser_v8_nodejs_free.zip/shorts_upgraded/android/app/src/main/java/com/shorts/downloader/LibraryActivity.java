package com.shorts.downloader;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.documentfile.provider.DocumentFile;

import java.util.ArrayList;
import java.util.Locale;

/** Local-first media and document library. Uses MediaStore and the Android file picker,
 * not broad all-files access permission. */
public class LibraryActivity extends Activity {
    private static final String PREFS = "shorts_browser";
    private static final String KEY_TREE = "library_tree_uri";
    private static final String KEY_DOWNLOADS_TREE = "downloads_tree_uri";
    private static final int PICK_FILE = 101;
    private static final int PICK_PDF = 102;
    private static final int PICK_BOOK = 103;
    private static final int PICK_TREE = 104;
    private static final int REQ_MEDIA = 105;
    private static final int REQ_LEGACY_STORAGE = 106;

    private final int bg = Color.rgb(11, 13, 19);
    private final int card = Color.rgb(19, 23, 34);
    private final int card2 = Color.rgb(27, 32, 44);
    private final int line = Color.rgb(45, 52, 67);
    private final int ink = Color.rgb(238, 240, 247);
    private final int muted = Color.rgb(145, 155, 173);
    private final int purple = Color.rgb(132, 93, 245);
    private LinearLayout root;
    private LinearLayout content;
    private String section = "all";
    private DocumentFile currentFolder;
    private final ArrayList<DocumentFile> folderStack = new ArrayList<>();
    private EditText fileSearch;
    private int pendingPicker = PICK_FILE;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        section = getIntent().getStringExtra("section");
        if (section == null || section.trim().isEmpty()) section = "all";
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        buildShell();
        restoreFolder();
        render();
        if ("videos".equals(section) || "music".equals(section)) requestMediaPermission("videos".equals(section) ? "video" : "audio");
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(dp(16), dp(10), dp(16), dp(10));
        setContentView(root);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, dp(4), 0, dp(12));
        TextView back = text("‹", 30, ink, true);
        back.setGravity(Gravity.CENTER);
        header.addView(back, new LinearLayout.LayoutParams(dp(42), dp(42)));
        back.setOnClickListener(v -> handleBack());
        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("Your library", 20, ink, true);
        TextView subtitle = text("Files saved on this phone", 11, muted, false);
        titleBox.addView(title); titleBox.addView(subtitle);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        titleParams.setMargins(dp(5), 0, 0, 0); header.addView(titleBox, titleParams);
        TextView open = text("Open file", 12, ink, true);
        open.setGravity(Gravity.CENTER);
        open.setPadding(dp(10), 0, dp(10), 0);
        open.setBackground(round(card2, line, 11));
        header.addView(open, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)));
        open.setOnClickListener(v -> pickAnyFile());
        root.addView(header);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setGravity(Gravity.CENTER_VERTICAL);
        tabs.setPadding(0, 0, 0, dp(10));
        String[][] items = {{"all", "All"}, {"videos", "Videos"}, {"music", "Music"}, {"documents", "PDFs & books"}, {"downloads", "Downloads"}};
        for (String[] item : items) {
            TextView tab = text(item[1], 11, section.equals(item[0]) ? Color.WHITE : muted, section.equals(item[0]));
            tab.setGravity(Gravity.CENTER);
            tab.setPadding(dp(11), dp(10), dp(11), dp(10));
            tab.setBackground(round(section.equals(item[0]) ? purple : card2, section.equals(item[0]) ? purple : line, 12));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38));
            lp.setMargins(0, 0, dp(6), 0);
            tabs.addView(tab, lp);
            tab.setOnClickListener(v -> { section = item[0]; currentFolder = null; folderStack.clear(); render(); });
        }
        root.addView(tabs);

        fileSearch = new EditText(this);
        fileSearch.setSingleLine(true);
        fileSearch.setTextSize(13);
        fileSearch.setTextColor(ink);
        fileSearch.setHintTextColor(muted);
        fileSearch.setHint("Find a file by name");
        fileSearch.setPadding(dp(13), 0, dp(13), 0);
        fileSearch.setBackground(round(card2, line, 13));
        root.addView(fileSearch, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));
        fileSearch.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { renderItemsOnly(); }
            @Override public void afterTextChanged(android.text.Editable s) {}
        });

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(12), 0, dp(20));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    private void render() {
        if (fileSearch != null && fileSearch.getText().length() > 0) fileSearch.setText("");
        content.removeAllViews();
        if (currentFolder != null) {
            renderFolder(currentFolder);
            return;
        }
        switch (section) {
            case "videos": renderMedia(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video"); break;
            case "music": renderMedia(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "audio"); break;
            case "documents": renderDocuments(); break;
            case "downloads": renderDownloads(); break;
            case "folder": renderChooseFolder(); break;
            default: renderAll(); break;
        }
    }

    private void renderItemsOnly() {
        if (content == null) return;
        if (currentFolder != null) renderFolder(currentFolder);
        else if ("videos".equals(section)) renderMedia(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video");
        else if ("music".equals(section)) renderMedia(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "audio");
        else if ("downloads".equals(section)) renderDownloads();
        else if ("documents".equals(section)) renderDocuments();
        else renderAll();
    }

    private void renderAll() {
        String search = fileSearch == null ? "" : fileSearch.getText().toString().trim();
        if (!search.isEmpty()) {
            addHero("Files matching “" + search + "”", "Search covers media you have allowed Shorts Browser to read. For PDFs and books, choose the folder that contains them.");
            int found = 0;
            if (hasMediaPermission("video")) {
                ArrayList<MediaRow> videos = queryMedia(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video", search);
                for (MediaRow row : videos) { addMediaRow(row, "video"); found++; }
            }
            if (hasMediaPermission("audio")) {
                ArrayList<MediaRow> audio = queryMedia(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "audio", search);
                for (MediaRow row : audio) { addMediaRow(row, "audio"); found++; }
            }
            if (found == 0) addSmallNote("No matching media was found. Open a folder or use Open any file to find a document.");
            addSecondary("Browse folders", this::pickFolder);
            addSecondary("Open any file", this::pickAnyFile);
            return;
        }
        addHero("Everything you save, in one place", "Watch your films, play music, read PDFs and open novels stored on this phone.");
        addAction("▶", "Videos", "Browse films and clips", () -> { section = "videos"; render(); });
        addAction("♫", "Music", "Play audio files", () -> { section = "music"; render(); });
        addAction("▤", "PDFs and books", "Open PDFs, EPUB novels and text books", () -> { section = "documents"; render(); });
        addAction("↓", "Downloads", "Browse files downloaded from websites", () -> { section = "downloads"; render(); });
        addPrimary("Browse a folder", this::pickFolder);
        addSecondary("Open any file", this::pickAnyFile);
        boolean hasRecentMedia = false;
        if (hasMediaPermission("video")) {
            ArrayList<MediaRow> videos = queryMedia(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video", "");
            if (!videos.isEmpty()) {
                addSmallNote("Recently added videos");
                for (int i = 0; i < Math.min(3, videos.size()); i++) addMediaRow(videos.get(i), "video");
                hasRecentMedia = true;
            }
        }
        if (hasMediaPermission("audio")) {
            ArrayList<MediaRow> audio = queryMedia(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "audio", "");
            if (!audio.isEmpty()) {
                addSmallNote("Recently added music");
                for (int i = 0; i < Math.min(3, audio.size()); i++) addMediaRow(audio.get(i), "audio");
                hasRecentMedia = true;
            }
        }
        if (!hasRecentMedia) addSmallNote("Your media appears here after you allow access. You can also open a single file or choose a folder.");
        addSmallNote("For privacy, Android asks which media, files or folders Shorts Browser can open. You do not need to grant unrestricted access to every file.");
    }

    private void renderChooseFolder() {
        addHero("Choose a folder", "Select a folder such as Downloads, Movies, Music or Documents. Shorts Browser can remember the folder you choose.");
        addPrimary("Choose folder", this::pickFolder);
        addSecondary("Open one file instead", this::pickAnyFile);
    }

    private void renderDocuments() {
        addHero("Read and open documents", "Choose a PDF or book on your phone. EPUB and plain-text novels open in the built-in reader.");
        addAction("PDF", "Open a PDF", "Study notes, manuals and documents", this::pickPdf);
        addAction("Aa", "Read a novel or ebook", "EPUB and TXT books", this::pickBook);
        addAction("▤", "Browse all files", "Choose a document from any folder", this::pickAnyFile);
        addAction("▣", "Choose a folder", "Keep a folder available in your library", this::pickFolder);
        showSelectedFolderHint();
        addSmallNote("Word documents, spreadsheets and file types without a built-in viewer can open in another compatible app if one is installed.");
    }

    private void renderDownloads() {
        addHero("Downloads", "Files saved from websites using the browser's normal download option appear in your phone's Downloads folder.");
        if (currentFolder != null) { renderFolder(currentFolder); return; }
        DocumentFile saved = getSavedDownloadsFolder();
        if (saved != null) {
            addAction("▣", saved.getName() == null ? "Downloads folder" : saved.getName(), "Browse files in your selected Downloads folder", () -> { currentFolder = saved; folderStack.clear(); render(); });
        } else {
            addSecondary("Choose your Downloads folder", this::pickFolder);
        }
        addPrimary("Open a downloaded file", this::pickAnyFile);
        addSmallNote("Website downloads are handled by Android's Download Manager. Some streaming sites do not expose a downloadable file.");
    }

    private void renderMedia(Uri collection, String kind) {
        if (!hasMediaPermission(kind)) {
            addHero("Allow media access", "To list videos or music already on your phone, grant access to that media type. You can still choose a single file without granting library access.");
            addPrimary("Allow " + ("video".equals(kind) ? "video" : "music") + " access", () -> requestMediaPermission(kind));
            addSecondary("Choose one file instead", this::pickAnyFile);
            return;
        }
        String search = fileSearch == null ? "" : fileSearch.getText().toString().trim();
        ArrayList<MediaRow> rows = queryMedia(collection, kind, search);
        int shown = 0;
        for (MediaRow row : rows) { addMediaRow(row, kind); shown++; }
        if (shown == 0) addSmallNote(search.isEmpty() ? "No matching files were found. Try Browse a folder or Open a file." : "No files match that name.");
        if (rows.size() >= 200) addSmallNote("Showing up to 200 files. Use search or browse a folder to find older items.");
        addSecondary("Browse another folder", this::pickFolder);
        addSecondary("Open a file", this::pickAnyFile);
    }

    private ArrayList<MediaRow> queryMedia(Uri collection, String kind, String nameFilter) {
        ArrayList<MediaRow> rows = new ArrayList<>();
        String[] projection = {MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE};
        if ("video".equals(kind)) projection = new String[]{MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE, MediaStore.Video.VideoColumns.DURATION};
        else projection = new String[]{MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE, MediaStore.Audio.AudioColumns.DURATION};
        String normalizedFilter = nameFilter == null ? "" : nameFilter.trim();
        String selection = normalizedFilter.isEmpty() ? null : MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ?";
        String[] selectionArgs = normalizedFilter.isEmpty() ? null : new String[]{"%" + normalizedFilter + "%"};
        try (Cursor cursor = getContentResolver().query(collection, projection, selection, selectionArgs, MediaStore.MediaColumns.DATE_ADDED + " DESC")) {
            if (cursor == null) return rows;
            int idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID);
            int nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME);
            int sizeCol = cursor.getColumnIndex(MediaStore.MediaColumns.SIZE);
            int durCol = cursor.getColumnIndex("duration");
            while (cursor.moveToNext() && rows.size() < 200) {
                long id = cursor.getLong(idCol);
                String name = cursor.getString(nameCol);
                Uri itemUri = Uri.withAppendedPath(collection, String.valueOf(id));
                long size = sizeCol >= 0 ? cursor.getLong(sizeCol) : 0;
                long duration = durCol >= 0 ? cursor.getLong(durCol) : 0;
                rows.add(new MediaRow(itemUri, name == null ? "Untitled file" : name, size, duration, kind));
            }
        } catch (SecurityException e) { toast("Android hasn't granted access to these files."); }
        catch (Exception e) { toast("Couldn't read the media library."); }
        return rows;
    }

    private void addMediaRow(MediaRow row, String kind) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.HORIZONTAL); item.setGravity(Gravity.CENTER_VERTICAL); item.setPadding(dp(12), dp(10), dp(10), dp(10));
        item.setBackground(round(card, line, 14));
        TextView art = text("video".equals(kind) ? "▶" : "♫", 19, Color.rgb(190, 176, 255), true);
        art.setGravity(Gravity.CENTER); art.setBackground(round(card2, line, 11));
        item.addView(art, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout detail = new LinearLayout(this); detail.setOrientation(LinearLayout.VERTICAL);
        TextView name = text(row.name, 13, ink, true); name.setMaxLines(2); name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        String meta = formatSize(row.size) + (row.duration > 0 ? " · " + formatDuration(row.duration) : "");
        detail.addView(name); detail.addView(text(meta, 10, muted, false));
        LinearLayout.LayoutParams detailParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        detailParams.setMargins(dp(11), 0, dp(8), 0); item.addView(detail, detailParams);
        item.addView(text("›", 24, muted, false));
        item.setOnClickListener(v -> openDocumentUri(row.uri, row.name, "video".equals(kind) ? "video/*" : "audio/*"));
        LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        itemLp.setMargins(0, 0, 0, dp(8)); content.addView(item, itemLp);
    }

    private void renderFolder(DocumentFile folder) {
        String folderName;
        DocumentFile[] files;
        try {
            folderName = folder.getName();
            files = folder.listFiles();
        } catch (SecurityException e) {
            currentFolder = null;
            String key = "downloads".equals(section) ? KEY_DOWNLOADS_TREE : KEY_TREE;
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(key).apply();
            addHero("Folder access expired", "Android no longer allows access to this folder. Choose it again to continue browsing.");
            addPrimary("Choose folder again", this::pickFolder);
            addSecondary("Open one file", this::pickAnyFile);
            return;
        } catch (Exception e) {
            addSmallNote("This folder couldn't be opened. Choose it again or open a file directly.");
            addPrimary("Choose another folder", this::pickFolder);
            return;
        }
        addHero(folderName == null ? "Files" : folderName, "Browse folders and open supported files. Use the folder picker to change the library location.");
        addSecondary("Choose another folder", this::pickFolder);
        if (files == null || files.length == 0) { addSmallNote("This folder is empty or Android no longer allows access. Choose the folder again if needed."); return; }
        java.util.Arrays.sort(files, (a,b) -> {
            if (a.isDirectory() != b.isDirectory()) return a.isDirectory() ? -1 : 1;
            String an = a.getName() == null ? "" : a.getName();
            String bn = b.getName() == null ? "" : b.getName();
            return an.compareToIgnoreCase(bn);
        });
        String search = fileSearch == null ? "" : fileSearch.getText().toString().trim().toLowerCase(Locale.ROOT);
        int shown = 0;
        for (DocumentFile file : files) {
            String name = file.getName() == null ? "Unnamed" : file.getName();
            if (!search.isEmpty() && !name.toLowerCase(Locale.ROOT).contains(search)) continue;
            if (shown >= 200) { addSmallNote("Showing the first 200 items in this folder. Use search or open a folder to narrow the list."); break; }
            String icon = file.isDirectory() ? "▣" : iconFor(name);
            addAction(icon, name, file.isDirectory() ? "Folder" : formatSize(file.length()), () -> {
                if (file.isDirectory()) { folderStack.add(currentFolder); currentFolder = file; render(); }
                else openDocumentUri(file.getUri(), name, file.getType());
            });
            shown++;
        }
        if (shown == 0) addSmallNote(search.isEmpty() ? "No files are available here." : "No files match that name.");
    }

    private void showSelectedFolderHint() {
        DocumentFile folder = getSavedFolder();
        if (folder != null) {
            String name = folder.getName() == null ? "Selected folder" : folder.getName();
            addAction("▣", name, "Browse this selected folder", () -> { currentFolder = folder; folderStack.clear(); render(); });
        }
    }

    private void restoreFolder() {
        String key;
        if ("folder".equals(section)) key = KEY_TREE;
        else if ("downloads".equals(section)) key = KEY_DOWNLOADS_TREE;
        else return;
        String saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(key, "");
        if (saved == null || saved.isEmpty()) return;
        try { currentFolder = DocumentFile.fromTreeUri(this, Uri.parse(saved)); }
        catch (Exception ignored) { currentFolder = null; }
    }
    private DocumentFile getSavedFolder() { return getSavedFolder(KEY_TREE); }
    private DocumentFile getSavedDownloadsFolder() { return getSavedFolder(KEY_DOWNLOADS_TREE); }
    private DocumentFile getSavedFolder(String key) {
        String saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(key, "");
        if (saved == null || saved.isEmpty()) return null;
        try { return DocumentFile.fromTreeUri(this, Uri.parse(saved)); }
        catch (Exception ignored) { return null; }
    }

    private void pickFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(intent, PICK_TREE); }
        catch (Exception e) { toast("Android's folder picker isn't available on this device."); }
    }
    private void pickAnyFile() { pickDocument("*/*", PICK_FILE); }
    private void pickPdf() { pickDocument("application/pdf", PICK_PDF); }
    private void pickBook() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/epub+zip", "text/plain", "text/html", "application/pdf"});
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        launchPicker(intent, PICK_BOOK);
    }
    private void pickDocument(String type, int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType(type);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        launchPicker(intent, requestCode);
    }
    private void launchPicker(Intent intent, int requestCode) {
        try { startActivityForResult(intent, requestCode); }
        catch (Exception e) { toast("Android's file picker isn't available on this device."); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == PICK_TREE) {
            boolean isDownloadsFolder = "downloads".equals(section);
            String treeKey = isDownloadsFolder ? KEY_DOWNLOADS_TREE : KEY_TREE;
            boolean persisted = false;
            try {
                int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                int readFlags = flags & Intent.FLAG_GRANT_READ_URI_PERMISSION;
                if (readFlags != 0) getContentResolver().takePersistableUriPermission(uri, readFlags);
                persisted = readFlags != 0;
            } catch (Exception ignored) { /* Some document providers grant access only for this session. */ }
            SharedPreferences.Editor editor = getSharedPreferences(PREFS, MODE_PRIVATE).edit();
            if (persisted) editor.putString(treeKey, uri.toString()); else editor.remove(treeKey);
            editor.apply();
            try {
                currentFolder = DocumentFile.fromTreeUri(this, uri);
                folderStack.clear(); section = isDownloadsFolder ? "downloads" : "all"; render();
                toast(persisted ? "Folder added to your library." : "Folder opened for this session.");
            } catch (Exception e) {
                currentFolder = null;
                toast("This folder couldn't be opened. Choose another folder.");
            }
            return;
        }
        try {
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(uri, flags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { /* Some providers don't offer persistent grants. */ }
        String name = getDisplayName(uri);
        openDocumentUri(uri, name, getContentResolver().getType(uri));
    }

    private void openDocumentUri(Uri uri, String name, String mimeType) {
        String lower = name == null ? "" : name.toLowerCase(Locale.ROOT);
        String type = mimeType == null ? "" : mimeType.toLowerCase(Locale.ROOT);
        Intent intent;
        if (lower.endsWith(".pdf") || type.equals("application/pdf")) {
            intent = new Intent(this, PdfViewerActivity.class);
            intent.setData(uri); intent.putExtra("displayName", name);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(intent); return;
        }
        if (lower.endsWith(".epub") || lower.endsWith(".txt") || lower.endsWith(".md") || lower.endsWith(".html") || lower.endsWith(".htm")
                || type.equals("text/plain") || type.equals("application/epub+zip") || type.equals("text/html")) {
            intent = new Intent(this, BookReaderActivity.class);
            intent.setData(uri); intent.putExtra("displayName", name);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(intent); return;
        }
        if (isVideo(lower, type)) {
            intent = new Intent(this, VideoPlayerActivity.class); intent.setData(uri);
            intent.putExtra("displayName", name); intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(intent); return;
        }
        if (isAudio(lower, type)) {
            intent = new Intent(this, MusicPlayerActivity.class); intent.setData(uri);
            intent.putExtra("displayName", name); intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(intent); return;
        }
        Intent external = new Intent(Intent.ACTION_VIEW);
        external.setDataAndType(uri, type.isEmpty() ? "*/*" : type);
        external.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(external); }
        catch (Exception e) { toast("No app is installed to open this file type."); }
    }

    private boolean isVideo(String name, String mime) {
        return mime.startsWith("video/") || name.matches(".*\\.(mp4|m4v|mkv|webm|mov|avi|3gp|ts|mpeg|mpg)$");
    }
    private boolean isAudio(String name, String mime) {
        return mime.startsWith("audio/") || name.matches(".*\\.(mp3|m4a|aac|ogg|opus|wav|flac|mid|midi|amr)$");
    }
    private String iconFor(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".pdf")) return "PDF";
        if (n.endsWith(".epub") || n.endsWith(".txt") || n.endsWith(".md")) return "Aa";
        if (isVideo(n, "")) return "▶";
        if (isAudio(n, "")) return "♫";
        return "▤";
    }
    private String getDisplayName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        } catch (Exception ignored) {}
        String last = uri.getLastPathSegment(); return last == null ? "Selected file" : last;
    }

    private boolean hasMediaPermission(String kind) {
        if (Build.VERSION.SDK_INT >= 33) {
            String permission = "video".equals(kind) ? Manifest.permission.READ_MEDIA_VIDEO : Manifest.permission.READ_MEDIA_AUDIO;
            if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) return true;
            return "video".equals(kind) && Build.VERSION.SDK_INT >= 34
                    && checkSelfPermission("android.permission.READ_MEDIA_VISUAL_USER_SELECTED") == PackageManager.PERMISSION_GRANTED;
        }
        if (Build.VERSION.SDK_INT >= 23) return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        return true;
    }
    private void requestMediaPermission(String kind) {
        if (Build.VERSION.SDK_INT >= 33) {
            ArrayList<String> permissions = new ArrayList<>();
            String specific = "video".equals(kind) ? Manifest.permission.READ_MEDIA_VIDEO : Manifest.permission.READ_MEDIA_AUDIO;
            if (checkSelfPermission(specific) != PackageManager.PERMISSION_GRANTED) permissions.add(specific);
            if ("video".equals(kind) && Build.VERSION.SDK_INT >= 34
                    && checkSelfPermission("android.permission.READ_MEDIA_VISUAL_USER_SELECTED") != PackageManager.PERMISSION_GRANTED) {
                permissions.add("android.permission.READ_MEDIA_VISUAL_USER_SELECTED");
            }
            if (!permissions.isEmpty()) requestPermissions(permissions.toArray(new String[0]), REQ_MEDIA);
        } else if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_LEGACY_STORAGE);
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MEDIA || requestCode == REQ_LEGACY_STORAGE) render();
    }

    private void addHero(String title, String description) {
        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(15), dp(16), dp(15), dp(16)); panel.setBackground(round(card, line, 17));
        panel.addView(text(title, 17, ink, true)); TextView desc = text(description, 12, muted, false); desc.setPadding(0, dp(7), 0, 0); panel.addView(desc);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); lp.setMargins(0, 0, 0, dp(12)); content.addView(panel, lp);
    }
    private void addAction(String symbol, String title, String subtitle, Runnable action) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(11), dp(10), dp(10), dp(10)); row.setBackground(round(card, line, 14));
        TextView icon = text(symbol, 17, Color.rgb(193, 178, 255), true); icon.setGravity(Gravity.CENTER); icon.setBackground(round(card2, line, 10)); row.addView(icon, new LinearLayout.LayoutParams(dp(41), dp(41)));
        LinearLayout details = new LinearLayout(this); details.setOrientation(LinearLayout.VERTICAL); details.addView(text(title, 12, ink, true)); TextView sub = text(subtitle, 10, muted, false); sub.setPadding(0, dp(4), 0, 0); details.addView(sub);
        LinearLayout.LayoutParams detailsLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); detailsLp.setMargins(dp(11), 0, dp(8), 0); row.addView(details, detailsLp); row.addView(text("›", 23, muted, false));
        row.setOnClickListener(v -> action.run()); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); lp.setMargins(0, 0, 0, dp(8)); content.addView(row, lp);
    }
    private void addPrimary(String label, Runnable action) {
        TextView button = text(label, 13, Color.WHITE, true); button.setGravity(Gravity.CENTER); button.setBackground(round(purple, purple, 12)); button.setPadding(dp(12), dp(12), dp(12), dp(12)); button.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(45)); lp.setMargins(0, 0, 0, dp(9)); content.addView(button, lp);
    }
    private void addSecondary(String label, Runnable action) {
        TextView button = text(label, 12, ink, true); button.setGravity(Gravity.CENTER); button.setBackground(round(card2, line, 12)); button.setPadding(dp(12), dp(11), dp(12), dp(11)); button.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); lp.setMargins(0, 0, 0, dp(9)); content.addView(button, lp);
    }
    private void addSmallNote(String label) {
        TextView note = text(label, 11, muted, false); note.setLineSpacing(dp(3), 1f); note.setPadding(dp(3), dp(8), dp(3), dp(12)); content.addView(note);
    }
    private TextView text(String value, float size, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(value); v.setTextSize(size); v.setTextColor(color); if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return v;
    }
    private android.graphics.drawable.Drawable round(int color, int stroke, int radius) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); d.setStroke(dp(1), stroke); return d;
    }
    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
    private void handleBack() {
        if (!folderStack.isEmpty()) { currentFolder = folderStack.remove(folderStack.size() - 1); render(); return; }
        if (currentFolder != null && !"all".equals(section)) { currentFolder = null; render(); return; }
        finish();
    }
    @Override public void onBackPressed() { handleBack(); }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(Locale.getDefault(), "%.0f KB", bytes / 1024f);
        if (bytes < 1024L * 1024L * 1024L) return String.format(Locale.getDefault(), "%.1f MB", bytes / (1024f * 1024f));
        return String.format(Locale.getDefault(), "%.1f GB", bytes / (1024f * 1024f * 1024f));
    }
    private String formatDuration(long durationMs) {
        long total = durationMs / 1000; long hours = total / 3600; long mins = (total % 3600) / 60; long secs = total % 60;
        return hours > 0 ? String.format(Locale.getDefault(), "%d:%02d:%02d", hours, mins, secs) : String.format(Locale.getDefault(), "%d:%02d", mins, secs);
    }
    private static final class MediaRow {
        final Uri uri; final String name; final long size; final long duration; final String type;
        MediaRow(Uri uri, String name, long size, long duration, String type) { this.uri = uri; this.name = name; this.size = size; this.duration = duration; this.type = type; }
    }
}
