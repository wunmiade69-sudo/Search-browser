# Replace the old downloader with Shorts Browser 8.0

This release removes the old Python/`yt-dlp` short-link service. The Android app is standalone and Node.js-free: it does not use a Node.js backend, npm, npx or a local server. Browser JavaScript runs only inside Android System WebView. APK compilation uses JDK 17, Gradle and the Android SDK.

## A. Update the GitHub repository from Termux

1. Download `shorts_browser_v8.zip` to your phone's **Downloads** folder.
2. Stop the old Python server in Termux with `Ctrl+C`.
3. Make a backup of the old checkout:

   ```bash
   cd ~
   cp -a shorts_upgraded "shorts_upgraded_backup_$(date +%Y%m%d_%H%M%S)"
   ```

4. Extract v8 over the existing checkout (this keeps its hidden `.git` directory):

   ```bash
   unzip -o ~/storage/downloads/shorts_browser_v8.zip -d ~
   cd ~/shorts_upgraded
   bash scripts/convert_to_browser_only.sh
   ```

   The migration script removes the no-longer-used Flask UI, link extractor, `yt-dlp` dependency and old tests. Keep the backup until you've tested the new APK.

5. Review the change and commit it:

   ```bash
   git status --short
   git add -A
   git commit -m "Repurpose Shorts as a standalone browser and local media library"
   git push
   ```

   If Git asks for your identity, configure a display name and the email associated with your GitHub account. Don't paste an access token into chat.

## B. Build and install the APK

1. Open the private repository on GitHub and choose **Actions → Build Android Browser APK → Run workflow**. A push to the changed Android files should also start it automatically.
2. Wait for the run to finish successfully.
3. Download `shorts-browser-debug-apk` from the run's Artifacts section and unzip it to get `app-debug.apk`.
4. Copy the APK to your phone. Install it from your file manager.
5. If Android reports that the new package conflicts with an already installed Shorts app, uninstall the old APK and install the new one. This may remove old app-specific bookmarks/settings; files in the phone's public Downloads folder are not removed by uninstalling the app.

## C. First run and local files

The browser opens directly to its bundled home page. Search terms and website addresses load in the APK's own WebView; they don't use Chrome as a handoff. Use the top tab icon to switch tabs and the reload icon to refresh the current page. The standalone APK does not need the old Python server, Flask, `yt-dlp`, Node.js, npm or `npx`.

Open **Library** from the home screen or browser menu:

- **Videos** lists accessible video files and opens them in the built-in player.
- **Music** lists accessible audio files and opens the built-in music player.
- **PDFs & books** opens PDF and EPUB/TXT readers or lets you choose a document.
- **Downloads** lets you select your Downloads folder so it can be browsed later. Downloads and the general library use separate folder selections so choosing Movies does not accidentally replace the Downloads location.
- **Browse a folder** asks Android for permission to that folder and only that folder. You can revoke access in Android settings.

The first time you open Videos or Music, Android may ask permission to read those media types. You can deny library access and still open a single file with **Open file**.

Websites that expose a direct file link can use Android Download Manager and save to Downloads. The old short-link extractor has intentionally been removed. Some streaming websites don't expose a downloadable file; watch those through their own web player instead. The old short-link input, social-site extraction, and automatic page video scraper are intentionally gone.

## D. If the APK build fails

Open the failed GitHub Actions run, expand the failing step, and share the error text (not any secret/token). Don't delete the repository or re-run `git init`; the existing repository is being reused.
