# Node.js-free audit — Shorts Browser 8.0

Audit date: 2026-10-18

## Result

The application has no Node.js backend and does not use Node.js, npm, or npx to run or build the APK. Android code is Java; its UI JavaScript runs inside Android System WebView. The APK build uses JDK 17, Gradle 8.9, Android SDK 34, and AndroidX WebKit/DocumentFile.

## Checks applied

- Removed `node --check` from GitHub Actions; CI checks the source with the Python checker and compiles with Gradle.
- Confirmed no `package.json`, npm/yarn/pnpm lock file, or `node_modules` directory is in the release ZIP.
- Added regression assertions to `scripts/check_browser_only.py` to reject Node/npm project manifests and Node.js/npm/npx commands in the Android build workflow.
- Confirmed Gradle dependencies are limited to the Android Gradle Plugin and AndroidX WebKit/DocumentFile.
- Confirmed the standalone release does not ship the legacy Flask/yt-dlp app or require a local server.

Note: GitHub's hosted runners/actions have their own implementation details, but this project does not require Node.js as an app runtime or build command. JavaScript itself is still used as the browser UI language in WebView, which is different from using Node.js.
