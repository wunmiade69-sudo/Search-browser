#!/usr/bin/env python3
"""Dependency-free checks for the standalone Android browser release."""
from __future__ import annotations

import re
import sys
import xml.etree.ElementTree as ET
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ANDROID = ROOT / "android/app/src/main"
ASSETS = ANDROID / "assets"
JAVA = ANDROID / "java/com/shorts/downloader"

class IdCollector(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.ids: set[str] = set()
    def handle_starttag(self, tag, attrs):
        for key, value in attrs:
            if key == "id" and value:
                self.ids.add(value)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def main() -> int:
    html_path = ASSETS / "browser.html"
    css_path = ASSETS / "browser.css"
    js_path = ASSETS / "browser.js"
    manifest_path = ANDROID / "AndroidManifest.xml"
    icon_path = ANDROID / "res/drawable/ic_launcher.xml"

    for path in (html_path, css_path, js_path, manifest_path, icon_path):
        require(path.is_file() and path.stat().st_size > 0, f"Missing or empty required file: {path.relative_to(ROOT)}")

    html = html_path.read_text(encoding="utf-8")
    css = css_path.read_text(encoding="utf-8")
    js = js_path.read_text(encoding="utf-8")
    parser = IdCollector()
    parser.feed(html)
    ids = parser.ids
    require("meta name=\"viewport\"" in html or "name=\"viewport\"" in html, "Mobile viewport metadata missing")
    require("browser.css?v=8.0.0" in html and "browser.js?v=8.0.0" in html, "Cache-busted browser assets missing")

    # Every direct DOM id reference from JS must be represented in the HTML.
    literal_ids = set(re.findall(r"\$\(['\"]#([A-Za-z][A-Za-z0-9_-]*)['\"]\)", js))
    missing = sorted(literal_ids - ids)
    require(not missing, "JavaScript refers to missing HTML element IDs: " + ", ".join(missing))

    for engine in ("google", "bing", "brave", "duckduckgo", "yahoo", "ecosia", "startpage", "wikipedia", "youtube"):
        require(engine in html and engine in js, f"Search engine option missing from UI or logic: {engine}")

    main_java = (JAVA / "MainActivity.java").read_text(encoding="utf-8")
    for required in ("shorts://search", "shorts://open", "shorts://library"):
        require(required in js, f"Missing native browser route in UI: {required}")
    require('"newtab".equals(action)' in main_java and 'location.href = `shorts://search' in js,
            "Native search/new-tab command handling is missing")
    library_java = (JAVA / "LibraryActivity.java").read_text(encoding="utf-8")
    pdf_java = (JAVA / "PdfViewerActivity.java").read_text(encoding="utf-8")
    book_java = (JAVA / "BookReaderActivity.java").read_text(encoding="utf-8")
    music_java = (JAVA / "MusicPlayerActivity.java").read_text(encoding="utf-8")
    video_java = (JAVA / "VideoPlayerActivity.java").read_text(encoding="utf-8")
    for text, feature in ((main_java, "native browser shell"), (library_java, "local file library"),
                          (pdf_java, "PDF reader"), (book_java, "book reader"),
                          (music_java, "music player"), (video_java, "video player")):
        require(len(text.strip()) > 100, f"Missing Java implementation: {feature}")
    for required in ("ACTION_OPEN_DOCUMENT_TREE", "MediaStore.Video.Media", "MediaStore.Audio.Media", "PdfViewerActivity", "BookReaderActivity"):
        require(required in library_java, f"Local storage feature missing: {required}")
    require("PdfRenderer" in pdf_java, "Native PDF renderer missing")
    require("MediaPlayer" in music_java, "Native audio playback missing")
    require("VideoView" in video_java, "Native video playback missing")
    require("yt-dlp" not in main_java.lower() and "ytsearch" not in main_java.lower(), "Legacy short-link extractor remains in Android shell")
    require("DownloadManager" in main_java, "Regular browser downloads are not wired to Android DownloadManager")

    ns = {"android": "http://schemas.android.com/apk/res/android"}
    manifest = ET.parse(manifest_path).getroot()
    permissions = {e.attrib.get(f"{{{ns['android']}}}name", "") for e in manifest.findall("uses-permission")}
    require("android.permission.MANAGE_EXTERNAL_STORAGE" not in permissions, "Broad all-files permission must not be requested")
    require("android.permission.READ_MEDIA_VIDEO" in permissions and "android.permission.READ_MEDIA_AUDIO" in permissions,
            "Scoped video/audio permissions missing")
    activities = {e.attrib.get(f"{{{ns['android']}}}name", "") for e in manifest.find("application").findall("activity")}
    for activity in (".MainActivity", ".LibraryActivity", ".VideoPlayerActivity", ".MusicPlayerActivity", ".PdfViewerActivity", ".BookReaderActivity"):
        require(activity in activities, f"Activity missing from manifest: {activity}")
    ET.parse(icon_path)

    gradle = (ROOT / "android/app/build.gradle").read_text(encoding="utf-8")
    require('versionCode 10' in gradle and 'versionName "8.0.0"' in gradle, "Expected Android release version is not set")
    require("8.0.0" in html and "v=8.0.0" in html, "Browser UI release version/cache keys don't match")
    for legacy in (ROOT / "app.py", ROOT / "requirements.txt", ROOT / "templates", ROOT / "static"):
        require(not legacy.exists(), f"Legacy downloader source is still present: {legacy.relative_to(ROOT)}")
    require("short-link" in (ROOT / "README.md").read_text(encoding="utf-8").lower(), "README should document removal of the old link downloader")
    gitignore = (ROOT / ".gitignore").read_text(encoding="utf-8")
    require(".env" in gitignore, "Environment secrets must stay out of Git")

    # Node.js is not part of this browser app or APK build. JavaScript here runs
    # only in Android System WebView; APK compilation uses JDK + Gradle + Android SDK.
    forbidden_names = {"package.json", "package-lock.json", "npm-shrinkwrap.json", "yarn.lock", "pnpm-lock.yaml"}
    for item in ROOT.rglob("*"):
        if ".git" in item.parts or "build" in item.parts:
            continue
        require(item.name not in forbidden_names, f"Node/npm package artifact must not be present: {item.relative_to(ROOT)}")
        require(not (item.is_dir() and item.name == "node_modules"),
                f"Node.js dependency directory must not be present: {item.relative_to(ROOT)}")
    workflow = (ROOT / ".github/workflows/android.yml").read_text(encoding="utf-8").lower()
    require(not re.search(r"(?m)^\s*(?:node|npm|npx)\s", workflow),
            "Android CI must not invoke Node.js/npm/npx")
    gradle_files = list((ROOT / "android").rglob("*.gradle")) + list((ROOT / "android").rglob("*.gradle.kts"))
    for gradle_file in gradle_files:
        gradle_text = gradle_file.read_text(encoding="utf-8").lower()
        require("nodejs" not in gradle_text and "com.github.node-gradle" not in gradle_text,
                f"Node.js Gradle plugin/runtime must not be used: {gradle_file.relative_to(ROOT)}")
    print("PASS: standalone browser assets, route IDs, Android manifest, scoped permissions, local viewers and release version")
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except AssertionError as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        raise SystemExit(1)
