#!/usr/bin/env bash
# Run from the project root after extracting v8 into an older Shorts checkout.
# Removes the unused Flask/yt-dlp short-link downloader and its old UI/tests.
set -euo pipefail
cd "$(dirname "$0")/.."
rm -f app.py requirements.txt package.json package-lock.json tailwind.config.js Dockerfile .dockerignore .env.example
rm -f TERMUX_UPGRADE.md V7_2_RELEASE_NOTES.md REDESIGN_REVIEW.md V6_RELEASE_NOTES.md
rm -rf templates static tests node_modules
rm -f scripts/append-custom-css.cjs scripts/run_on_pc.sh scripts/run_on_pc.bat scripts/termux_setup.sh
rm -f .github/workflows/ci.yml
# Stop tracking old server secrets if they were ever committed; keep local files intact.
if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  git rm --cached -f --ignore-unmatch .env .env.local .env.production .env.development >/dev/null 2>&1 || true
fi
printf '%s\n' "Removed the legacy Python short-link downloader. The Android APK is now standalone; build it with GitHub Actions."
