# Shorts Browser 8.0 — Android browser and local library

Shorts Browser is being repurposed from the old short-link downloader into a standalone Android browser with a private local media library. **The browser APK no longer requires Termux, Flask, yt-dlp, Node.js, npm, or any local server.** Browser JavaScript runs inside Android System WebView; it is not a Node.js backend. APK builds use JDK 17, Gradle, and the Android SDK.

## What this version is for

- **Browse the web:** Google, Bing, Brave Search, DuckDuckGo, Yahoo, Ecosia, Startpage, Ask, Yandex, AOL Search, Qwant, Mojeek, Wikipedia and YouTube search are selectable from the address bar.
- **Browser basics:** Back, Forward, Home, address/search, reload, multiple tabs, bookmarks, history, a mobile/desktop user-agent switch, full-screen website video, cookie/storage clearing and regular browser downloads.
- **Local videos and films:** Lists videos Android grants access to, plays selected video files in the built-in player and supports full-screen web video.
- **Local music:** Lists audio files with permission and plays selected audio files in the built-in player with seek and play/pause controls. Persistent playback notifications and a multi-track queue are future enhancements.
- **PDF reader:** Opens a selected PDF in the built-in page-by-page reader.
- **Novel and ebook reader:** Opens EPUB and TXT files in a built-in text reader with adjustable font size and saved reading position. HTML/Markdown text files are also supported.
- **File manager:** Browse a folder that you explicitly select, reopen it later, or use Android's file picker to open an individual file. The app remembers a general library folder separately from a Downloads folder. Unsupported office formats can be handed to another compatible app.
- **Downloads:** Ordinary downloadable file links are handled by Android Download Manager and saved to the phone's Downloads folder when a website exposes a direct file. This is not a social-media link extractor and does not bypass logins, DRM or site restrictions.

The old short-link extraction flow, link-preview card, `yt-dlp` dependency and Python server are not part of this release.

## Storage and privacy

The app uses Android's scoped media permissions for videos/music and the Storage Access Framework for PDFs, books and folders. It does not request `MANAGE_EXTERNAL_STORAGE` (“all files access”). When you choose a folder, Android grants access to that folder; you can revoke it from Android settings. Search terms are sent to the search site you select. Browser cookies and website storage stay in the WebView profile on the device.

## Build a debug APK with GitHub Actions

1. Upload/push this project to a GitHub repository.
2. Open **Actions → Build Android Browser APK → Run workflow**.
3. Download the `shorts-browser-debug-apk` artifact from the successful run and extract `app-debug.apk`.
4. Install the APK on Android. If updating an older debug-signed version fails due to a signing-key mismatch, uninstall the old APK first; files saved in public Downloads stay on the phone.

The workflow does not invoke Node.js, npm or npx. It builds with JDK 17, Gradle 8.9 and Android SDK 34. The project requires internet access during the first build to fetch AndroidX WebKit and DocumentFile.

## Local build

Open `android/` in Android Studio or run:

```bash
gradle -p android assembleDebug --no-daemon
```

This requires JDK 17, the Android SDK platform/build tools for API 34, and Gradle 8.9. The APK output is `android/app/build/outputs/apk/debug/app-debug.apk`.

## Current limitations to test

- Streaming providers that don't expose a direct downloadable file must be watched on their website; the app no longer tries to extract short/social-media links.
- PDF rendering is a lightweight reader with page navigation; it is not a full annotation/OCR editor.
- EPUB support is a basic text reader. Complex fixed-layout books, DRM-protected ebooks and some embedded fonts/layouts may not render exactly like a dedicated ebook app.
- Downloads depend on the website's own direct file URL, cookie/session requirements and Android Download Manager.
- The project must be built and tested on your device before describing it as production-ready.
